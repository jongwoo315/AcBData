from django.apps import AppConfig


class MarcadorConfig(AppConfig):
    name = 'marcador'
